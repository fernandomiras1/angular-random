import { InjectionToken } from '@angular/core'

export const LAZY_COMPONENT = new InjectionToken<{ [key: string]: string }>('LAZY_COMPONENT')
