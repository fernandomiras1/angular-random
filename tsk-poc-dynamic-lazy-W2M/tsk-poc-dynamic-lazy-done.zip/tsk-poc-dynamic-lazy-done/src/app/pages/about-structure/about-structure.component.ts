import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-about-structure',
  templateUrl: './about-structure.component.html',
  styleUrls: ['./about-structure.component.scss'],
})
export class AboutStructureComponent implements OnInit {
  ngOnInit() {
  }
}
