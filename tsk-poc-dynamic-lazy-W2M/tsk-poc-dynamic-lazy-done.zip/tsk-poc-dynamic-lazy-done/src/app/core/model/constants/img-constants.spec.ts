import { ImgConstants } from './img-constants'

describe('ImgConstants', () => {
  it('should create an instance', () => {
    expect(new ImgConstants()).toBeTruthy()
  })
})
