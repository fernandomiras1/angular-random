export interface Image{
  urlImage: string;
  altImage?: string;
  imgStyleClass?: string;
}
