export interface BaseDto {
  typeComponent: string;
  enabledComponent: boolean;
  styleClass?: string;
}
