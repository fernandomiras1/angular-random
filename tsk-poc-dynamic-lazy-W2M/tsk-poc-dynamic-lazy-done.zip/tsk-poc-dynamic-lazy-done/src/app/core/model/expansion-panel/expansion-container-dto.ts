import { ExpansionContentDto } from './expansion-content-dto'

export interface ExpansionContainerDto{
  title: string;
  field: ExpansionContentDto[];
}
