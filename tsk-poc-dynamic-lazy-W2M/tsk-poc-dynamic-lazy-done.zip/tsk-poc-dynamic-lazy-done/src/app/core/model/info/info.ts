export interface Info {
  title: string;
  image: string;
  altText: string;
  description?: string;
  date?: string;
  urlPost?: string;
}
