export enum TextAlignType {
  CENTER = 'center',
  LEFT = 'left',
  RIGHT = 'right',
}
