export enum ComponentsEnum {
  ComponentAlert = 'component-alert',
  ComponentIcons = 'component-icons',
  ComponentImage = 'component-image',
  ComponentSubtitle ='component-subtitle',
  ComponentInfoText = 'component-info-text',
  ComponentCardsText='component-cards-text',
}
