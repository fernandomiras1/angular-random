export enum SizeEnum{
  LARGE='large',
  STANDARD='standard',
  SMALL='small'
}

export enum SizeColumnsEnum{
  LARGE = 'is-12',
  MEDIUM = 'is-9',
  SMALL = 'is-6',
}
