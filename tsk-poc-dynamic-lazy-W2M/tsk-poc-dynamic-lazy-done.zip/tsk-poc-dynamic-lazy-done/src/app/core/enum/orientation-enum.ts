export enum OrientationEnum {
  VERTICAL='vertical',
  HORIZONTAL='horizontal'
}
