export enum AlertTypeEnum{
 DEFAULT='default',
 INFO='info',
 SUCCESS='success',
 DANGER='danger',
 WARNING='warning'
}
